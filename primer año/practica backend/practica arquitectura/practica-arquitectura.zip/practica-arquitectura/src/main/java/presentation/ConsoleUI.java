package presentation;

import model.Product;
import service.ProductService;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class ConsoleUI {
	private ProductService service;
	private Scanner scanner =new Scanner(System.in);
	
	public ConsoleUI(ProductService service) {
		this.service=service;
	}
	public void start() {
		int option;
		do {
			System.out.println("===GESTION DE TAREAS===");
			System.out.println("1.Listar Tareas");
			System.out.println("2. Agregar");
			System.out.println("3.Editar tarea");
			System.out.println("4.Eliminar");
			System.out.println("0.Salir");
			option=Integer.parseInt(scanner.nextLine());
			
			try {
				switch(option) {
				case 1 : listProduct(); break;
				case 2 : addProduct(); break;
				case 3 : updateProduct(); break;
				case 4 : deleteProduct(); break;
				}
			}catch(Exception e) {
				System.out.println("Error"+ e.getMessage());
			}
		}while (option !=0);
	}
	private void listProduct() throws SQLException{
		List<Product> Productlist=service.getAllProducts();
		System.out.println("---Lista de tareas---");
		for(Product product : Productlist) {
			System.out.printf("[%d] %s - %s%n",product.getId(),product.getName(),product.getDescription());
			
		}
	}
	private void addProduct() throws SQLException{
		System.out.print("Nombre de la Tarea:");
		String name=scanner.nextLine();
		System.out.print("Descripcion de la Tarea:");
		String description=scanner.nextLine();
		service.addProduct(new Product(0,name,description));
		System.out.println("Tarea agregada con exito");
	}
	private void updateProduct() throws SQLException {
		System.out.print("ID de la tarea a editar: ");
		int id=Integer.parseInt(scanner.nextLine());
		Product product=service.getProductById(id);
		if (product==null) {
			System.out.println("Tarea no encontrada");
			return;
		}
		System.out.print("Nuevo nombre:");
		product.SetName(scanner.nextLine());
		System.out.print("Nueva descripcion: ");
		product.setDescription(scanner.nextLine());
		service.updateProduct(product);
		System.out.println("Tarea actualizada");
	}
	private void deleteProduct() throws SQLException {
		System.out.print("ID de la tarea a eliminar: ");
		int id=Integer.parseInt(scanner.nextLine());
		service.deleteProduct(id);
		System.out.println("Tarea eliminada");
	}
}
