import dao.ProductDAO;
import presentation.ConsoleUI;
import service.ProductService;

import java.sql.Connection;

public class Main {
	public static void main(String[] args) {
		try {
			Connection conn=Database.connect();
			ProductDAO dao= new ProductDAO(conn);
			ProductService service=new ProductService(dao);
			ConsoleUI ui=new ConsoleUI(service);
			ui.start();
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
}
