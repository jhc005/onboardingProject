package dao;
import model.Product;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO {
	private Connection conn;
	
	public ProductDAO(Connection conn) {
		this.conn=conn;
	}
	public void save(Product product)throws SQLException {
		String sql="INSERT INTO products(name,description) VALUES(?,?)";
		try (PreparedStatement stmt = conn.prepareStatement(sql)){
			stmt.setString(1, product.getName());
			stmt.setString(2, product.getDescription());
			stmt.executeUpdate();
		}	
	}
	public List<Product> findAll() throws SQLException{
		List<Product>list = new ArrayList<>();
		String sql="SELECT * FROM products";
		try(Statement stmt=conn.createStatement();
			ResultSet resultset=stmt.executeQuery(sql)){
			while(resultset.next()) {
				list.add(new Product(resultset.getInt("id"),resultset.getString("name"),resultset.getString("description")));
			}
		}
		return list;
	}
	public Product findById(int id) throws SQLException{
		String sql="SELECT * FROM products WHERE id=?";
		try (PreparedStatement stmt=conn.prepareStatement(sql)){
			stmt.setInt(1, id);
			ResultSet resultset=stmt.executeQuery();
			if (resultset.next()) {
				return new Product(resultset.getInt("id"),resultset.getString("name"),resultset.getString("description"));
			}
		}
		return null;
	}
	public void update(Product product) throws SQLException {
		String sql="UPDATE products SET nmae= ?,description =? WHERE id=?";
		try (PreparedStatement stmt=conn.prepareStatement(sql)){
			stmt.setString(1, product.getName());
			stmt.setString(2, product.getDescription());
			stmt.setInt(3, product.getId());
			stmt.executeUpdate();
		}
	}
	public void delete(int id) throws SQLException {
		String sql = "DELETE FROM products WHERE id = ?";
		try(PreparedStatement stmt=conn.prepareStatement(sql)){
			stmt.setInt(1, id);
			stmt.executeUpdate();
		}
	}
}
