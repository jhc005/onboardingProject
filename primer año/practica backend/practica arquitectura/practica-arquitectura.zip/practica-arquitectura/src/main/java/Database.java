import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Database {
	public static Connection connect() throws SQLException{
		Connection conn=DriverManager.getConnection("jdbc:sqlite:tasks.db");
		try(Statement stmt=conn.createStatement()){
			stmt.execute("CREATE TABLE IF NOT EXISTS products("
						+"id INTEGER PRIMARY KEY AUTOINCREMENT,"
						+"name TEXT NOT NULL,"
						+"description TEXT)");
		}
		return conn;
	}
}
