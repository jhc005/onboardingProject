package service;

import dao.ProductDAO;
import model.Product;

import java.sql.SQLException;
import java.util.List;


public class ProductService {
	private ProductDAO dao;
	
	public ProductService(ProductDAO dao) {
		this.dao=dao;
	}
	public void addProduct(Product product) throws SQLException {
		if (product.getName()==null||product.getName().isBlank()) {
			throw new IllegalArgumentException("El nombre no puede estar vacio");
		}
		dao.save(product);
	}
	public List<Product>getAllProducts() throws SQLException{
		return dao.findAll();
	}
	public Product getProductById(int id) throws SQLException {
		return dao.findById(id);
	}
	public void updateProduct(Product product) throws SQLException{
		dao.update(product);
	}
	public void deleteProduct(int id) throws SQLException{
		dao.delete(id);
	}
}
