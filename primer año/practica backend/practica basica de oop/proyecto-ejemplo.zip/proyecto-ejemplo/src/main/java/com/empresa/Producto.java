package com.empresa;

import java.util.HashSet;
import java.util.Set;

public class Producto {
	private String name;
	private String description;
	private double price;
	private int stock;
	private Set<Categorie> categories;
	
	public Producto(String name,String descrip,double price,int stock) {
		this.name=name;
		this.description=descrip;
		this.price=price;
		this.stock=stock;
		this.categories=new HashSet<Categorie>();
	}
	public String getName() {
		return name;
	}
	public String getDescription() {
		return description;
	}
	public double getPrice() {
		return price;
	}
	public int getStock() {
		return stock;
	}
	
	public void setName(String name) {
		if (!name.isBlank()) {
			this.name=name;
		}else {
			throw new IllegalArgumentException("Name can't be empty");
		}
	}
	public void setDescription(String description) {
		this.description=description;
	}
	public void setPrice(double price) {
		if (price>=0) {
			this.price=price;
		}else {
			throw new IllegalArgumentException("Price can't be negative");
		}
	}
	public void setStock(int stock) {
		if (price>=0) {
			this.stock=stock;
		}else {
			throw new IllegalArgumentException("Price can't be negative");
		}
	
	}
	public String resumen() {
		return String.format(
	            "Product: %s\nDescription: %s\nPrice: $%.2f\nStock disponible: %d unidades",
	            name, description, price, stock
	        );	
	}
	public void addCategorie(Categorie categorie) {
		if (categorie!=null) {
			categories.add(categorie);
		}else {
			throw new IllegalArgumentException("La categoria qu se quiere añadir no puede estar vacia");
		}
	}
	public void deleteCategorie(Categorie categorie) {
		categories.remove(categorie);
	}
}
