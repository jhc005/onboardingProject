package com.empresa;

public class Categorie{
	private String name;
	
	public Categorie(String name) {
		this.name=name;
	}
	public String getName() {
		return name;
	}
	public void setNombre(String name) {
		if (!name.isBlank()) {
			this.name=name;
		}else {
			throw new IllegalArgumentException("name cant be empty");
		}
	}
}
